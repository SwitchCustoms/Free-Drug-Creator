fx_version 'cerulean'
game 'gta5'

author 'Switch'
description 'Drug zone creator with admin menu and MySQL persistence'
version '1.0.0'

lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

client_scripts {
    'client.lua'
}

dependencies {
    'ox_lib',
    'ox_inventory',
    'oxmysql'
}