Config = {}

-- Marker / circle settings
Config.Marker = {
    type = 1,          -- 1 = cylinder marker
    scale = vec3(1.8, 1.8, 0.35),
    color = { r = 0, g = 255, b = 0, a = 180 },
    drawDistance = 25.0
}

-- Interaction
Config.InteractKey = 38 -- E
Config.InteractText = 'Pick up'

-- Tick time (0 = max responsiveness near zones)
Config.TickTime = 0