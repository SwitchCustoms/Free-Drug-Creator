local zones = {}
local showingText = false
local isHarvesting = {}

-- Animations
local AnimPresets = {
    { label = "Quick Pickup", dict = "pickup_object", anim = "pickup_low" },
    { label = "Crouch Inspect", dict = "amb@world_human_gardener_plant@male@idle_a", anim = "idle_a" },
    { label = "Crouch Search", dict = "amb@world_human_gardener_plant@male@enter", anim = "enter" }
}

-- Glow ring colors
local ColorPresets = {
    { label = "Green", value = { r = 0, g = 255, b = 0 } },
    { label = "Blue", value = { r = 0, g = 128, b = 255 } },
    { label = "Red", value = { r = 255, g = 0, b = 0 } },
    { label = "Yellow", value = { r = 255, g = 255, b = 0 } },
    { label = "Purple", value = { r = 180, g = 0, b = 255 } },
    { label = "Orange", value = { r = 255, g = 140, b = 0 } },
    { label = "White", value = { r = 255, g = 255, b = 255 } }
}

---------------------------------------------------------
-- ZONE SYNC
---------------------------------------------------------

RegisterNetEvent('drugcreator:client:setZones', function(serverZones)
    zones = serverZones or {}
end)

-- RELIABLE ZONE REQUEST: KEEP ASKING UNTIL WE ACTUALLY GET ZONES
CreateThread(function()
    while not PlayerPedId() or PlayerPedId() == 0 do
        Wait(200)
    end

    while zones == nil or next(zones) == nil do
        TriggerServerEvent('drugcreator:server:requestZones')
        Wait(500)
    end
end)

---------------------------------------------------------
-- REQUIRED ITEMS
---------------------------------------------------------

function buildRequiredItemInputs(existing)
    local inputs = {}
    for i = 1, 3 do
        local defaultItem = existing and existing[i] and existing[i].name or ""
        local defaultCount = existing and existing[i] and existing[i].count or 1

        inputs[#inputs+1] = { type = 'input', label = ('Required Item %d'):format(i), default = defaultItem }
        inputs[#inputs+1] = { type = 'number', label = ('Amount %d'):format(i), default = defaultCount, min = 1 }
    end
    return inputs
end

---------------------------------------------------------
-- GLOW RING
---------------------------------------------------------

local function drawCircle(zone)
    local radius = zone.radius or 2.0
    local c = zone.color or { r = 0, g = 255, b = 0 }
    local segments = 80
    local step = (2 * math.pi) / segments
    local glowRadius = radius + 0.05
    local glowLayers = 40

    for layer = 1, glowLayers do
        local alpha = math.floor(200 * (1 - (layer / glowLayers)))
        local z = zone.coords.z - 0.98 + (layer * 0.002)

        for i = 1, segments do
            local angle1 = (i - 1) * step
            local angle2 = i * step

            local x1 = zone.coords.x + math.cos(angle1) * glowRadius
            local y1 = zone.coords.y + math.sin(angle1) * glowRadius
            local x2 = zone.coords.x + math.cos(angle2) * glowRadius
            local y2 = zone.coords.y + math.sin(angle2) * glowRadius

            DrawLine(x1, y1, z, x2, y2, z, c.r, c.g, c.b, alpha)
        end
    end
end

---------------------------------------------------------
-- THREAD 1: SHOW PROMPT + DRAW RING
---------------------------------------------------------

CreateThread(function()
    while true do
        local sleep = 500
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local inside = false

        for id, zone in pairs(zones) do
            local dist = #(coords - zone.coords)
            if dist < 30.0 then
                sleep = 0
                drawCircle(zone)
                if dist < zone.radius then
                    inside = true
                end
            end
        end

        if inside and not showingText then
            showingText = true
            lib.showTextUI("[E] Harvest")
        elseif not inside and showingText then
            showingText = false
            lib.hideTextUI()
        end

        Wait(sleep)
    end
end)

---------------------------------------------------------
-- THREAD 2: HARVEST LOGIC
---------------------------------------------------------

CreateThread(function()
    while true do
        Wait(0)

        if not IsControlJustReleased(0, 38) then goto continue end

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        local closestId, closestZone, closestDist = nil, nil, 9999.0
        for id, zone in pairs(zones) do
            local dist = #(coords - zone.coords)
            if dist < zone.radius and dist < closestDist then
                closestId = id
                closestZone = zone
                closestDist = dist
            end
        end

        if closestId and closestZone then
            local id = closestId
            local zone = closestZone

            if isHarvesting[id] then
                lib.notify({ type = 'error', description = 'Already harvesting...' })
                goto continue
            end

            isHarvesting[id] = true

            local harvestTimeSeconds = zone.harvestTime or 3
            if harvestTimeSeconds < 1 then harvestTimeSeconds = 1 end
            local harvestTime = harvestTimeSeconds * 1000

            local dict = zone.animDict
            local anim = zone.animName
            if not dict or dict == "" or not anim or anim == "" then
                dict = AnimPresets[1].dict
                anim = AnimPresets[1].anim
            end

            CreateThread(function()
                local success = lib.progressCircle({
                    duration = harvestTime,
                    position = 'bottom',
                    label = 'Harvesting...',
                    canCancel = false,
                    disable = { move = true, car = true, combat = true },
                    anim = { dict = dict, clip = anim }
                })

                ClearPedTasks(PlayerPedId())

                if success then
                    TriggerServerEvent('drugcreator:server:pickup', id)
                end

                isHarvesting[id] = false
            end)
        end

        ::continue::
    end
end)

---------------------------------------------------------
-- ADMIN MENU
---------------------------------------------------------

RegisterCommand('drugcreator', function()
    local isAdmin = lib.callback.await('drugcreator:server:isAdmin', false)
    if not isAdmin then
        lib.notify({ type = 'error', description = 'You do not have permission.' })
        return
    end
    openMainMenu()
end)

RegisterKeyMapping('drugcreator', 'Open SwitchDrugCreator Admin Menu', 'keyboard', 'F6')

function openMainMenu()
    lib.registerContext({
        id = 'switchdrugcreator_main',
        title = '⚗️ SWITCHDRUGCREATOR',
        description = 'Advanced Drug Zone Management Suite',
        options = {
            { title = '➕ Create New Zone', icon = 'plus-circle', iconColor = 'green', onSelect = createZoneMenu },
            { title = '📋 Manage Existing Zones', icon = 'list', iconColor = 'blue', onSelect = manageZonesMenu }
        }
    })
    lib.showContext('switchdrugcreator_main')
end

---------------------------------------------------------
-- CREATE ZONE MENU (BLIP OPTIONS REMOVED)
---------------------------------------------------------

function createZoneMenu()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    local colorOptions, animOptions = {}, {}

    for i, c in ipairs(ColorPresets) do
        colorOptions[#colorOptions+1] = { label = c.label, value = i }
    end

    for i, a in ipairs(AnimPresets) do
        animOptions[#animOptions+1] = { label = a.label, value = i }
    end

    local step1 = lib.inputDialog('Create New Zone', {
        { type = 'input', label = 'Zone Label', required = true },
        { type = 'input', label = 'Item (ox_inventory name)', required = true },
        {
            type = 'select',
            label = 'Amount Mode',
            options = {
                { label = "Fixed Amount", value = "fixed" },
                { label = "Random Range (Min/Max)", value = "random" }
            },
            default = "fixed"
        }
    })

    if not step1 then return end

    local label = step1[1]
    local item = step1[2]
    local mode = step1[3] or "fixed"

    local amountInputs = {}

    if mode == "fixed" then
        amountInputs[#amountInputs+1] = {
            type = 'number',
            label = 'Fixed Amount',
            default = 1,
            min = 1
        }
    else
        amountInputs[#amountInputs+1] = {
            type = 'number',
            label = 'Min Amount',
            default = 1,
            min = 1
        }
        amountInputs[#amountInputs+1] = {
            type = 'number',
            label = 'Max Amount',
            default = 1,
            min = 1
        }
    end

    amountInputs[#amountInputs+1] = { type = 'number', label = 'Pickup Radius', default = 2.0, min = 0.5, step = 0.1 }
    amountInputs[#amountInputs+1] = { type = 'number', label = 'Harvest Time (seconds)', default = 3, min = 1 }
    amountInputs[#amountInputs+1] = { type = 'select', label = 'Glow Color', options = colorOptions, default = 1 }
    amountInputs[#amountInputs+1] = { type = 'select', label = 'Pickup Animation', options = animOptions, default = 1 }

    for _, v in ipairs(buildRequiredItemInputs(nil)) do
        amountInputs[#amountInputs+1] = v
    end

    local step2 = lib.inputDialog('Create Zone Settings', amountInputs)
    if not step2 then return end

    local idx = 1
    local fixedAmount, minAmount, maxAmount

    if mode == "fixed" then
        fixedAmount = step2[idx]; idx = idx + 1
    else
        minAmount = step2[idx]; idx = idx + 1
        maxAmount = step2[idx]; idx = idx + 1
    end

    local radius = step2[idx]; idx = idx + 1
    local harvestTime = step2[idx]; idx = idx + 1
    local color = ColorPresets[step2[idx]].value; idx = idx + 1

    local animPreset = AnimPresets[step2[idx]]
    local animDict = animPreset.dict
    local animName = animPreset.anim
    idx = idx + 1

    local required_items = {}
    for i = 1, 3 do
        local itemName = step2[idx]
        local itemCount = tonumber(step2[idx + 1])
        idx = idx + 2

        if itemName ~= "" and itemCount and itemCount > 0 then
            required_items[#required_items+1] = { name = itemName, count = itemCount }
        end
    end

    TriggerServerEvent('drugcreator:server:addZone', {
        label = label,
        item = item,
        amount_mode = mode,
        amount = fixedAmount,
        amount_min = minAmount,
        amount_max = maxAmount,
        radius = radius,
        harvestTime = harvestTime,
        coords = coords,
        required_items = required_items,
        color = color,
        animDict = animDict,
        animName = animName
    })
end

---------------------------------------------------------
-- MANAGE ZONES MENU
---------------------------------------------------------

function manageZonesMenu()
    local serverZones = lib.callback.await('drugcreator:server:getZones', false) or {}

    if not next(serverZones) then
        lib.notify({ type = 'info', description = 'No zones created yet.' })
        return
    end

    local options = {}

    for id, zone in pairs(serverZones) do
        options[#options+1] = {
            title = '🧪 ' .. zone.label,
            description = ('Item: %s • Amount: %s • Radius: %.1f • Time: %ds'):format(
                zone.item,
                zone.amount_mode == "random"
                    and (zone.amount_min .. "-" .. zone.amount_max)
                    or tostring(zone.amount),
                zone.radius,
                zone.harvestTime or 3
            ),
            icon = 'location-dot',
            menu = 'switchdrugcreator_zone_' .. id
        }

        lib.registerContext({
            id = 'switchdrugcreator_zone_' .. id,
            title = '🧪 Zone: ' .. zone.label,
            description = 'Edit or delete this zone',
            options = {
              {
        title = '📍 Teleport to Zone',
            icon = 'location-dot',
            iconColor = 'blue',
            onSelect = function()
        TriggerServerEvent('drugcreator:server:teleportToZone', tonumber(id))
    end
},

                {
                    title = '✏️ Edit Zone',
                    icon = 'pen-to-square',
                    iconColor = 'yellow',
                    onSelect = function()
                        editZoneMenu(id, zone)
                    end
                },
                {
                    title = '🗑️ Delete Zone',
                    icon = 'trash',
                    iconColor = 'red',
                    onSelect = function()
                        local confirm = lib.alertDialog({
                            header = 'Delete Zone?',
                            content = 'Are you sure you want to delete "' .. zone.label .. '"?',
                            centered = true,
                            cancel = true
                        })
                        if confirm == 'confirm' then
                            TriggerServerEvent('drugcreator:server:deleteZone', id)
                            Wait(200)
                            manageZonesMenu()
                        end
                    end
                }
            }
        })
    end

    lib.registerContext({
        id = 'switchdrugcreator_manage',
        title = '📋 Manage Zones',
        description = 'Edit or delete existing drug zones',
        options = options
    })

    lib.showContext('switchdrugcreator_manage')
end

---------------------------------------------------------
-- EDIT ZONE MENU (BLIP OPTIONS REMOVED)
---------------------------------------------------------

function editZoneMenu(id, zone)
    local colorOptions, animOptions = {}, {}
    local defaultColorIndex, defaultAnimIndex = 1, 1

    for i, preset in ipairs(ColorPresets) do
        colorOptions[#colorOptions+1] = { label = preset.label, value = i }
        if preset.value.r == zone.color.r and preset.value.g == zone.color.g and preset.value.b == zone.color.b then
            defaultColorIndex = i
        end
    end

    for i, a in ipairs(AnimPresets) do
        animOptions[#animOptions+1] = { label = a.label, value = i }
        if a.dict == zone.animDict and a.anim == zone.animName then
            defaultAnimIndex = i
        end
    end

    local step1 = lib.inputDialog('Edit Zone', {
        { type = 'input', label = 'Zone Label', default = zone.label, required = true },
        { type = 'input', label = 'Item (ox_inventory name)', default = zone.item, required = true },
        {
            type = 'select',
            label = 'Amount Mode',
            options = {
                { label = "Fixed Amount", value = "fixed" },
                { label = "Random Range (Min/Max)", value = "random" }
            },
            default = zone.amount_mode or "fixed"
        }
    })

    if not step1 then return end

    local label = step1[1]
    local item = step1[2]
    local mode = step1[3] or "fixed"

    local amountInputs = {}

    if mode == "fixed" then
        amountInputs[#amountInputs+1] = {
            type = 'number',
            label = 'Fixed Amount',
            default = zone.amount or 1,
            min = 1
        }
    else
        amountInputs[#amountInputs+1] = {
            type = 'number',
            label = 'Min Amount',
            default = zone.amount_min or 1,
            min = 1
        }
        amountInputs[#amountInputs+1] = {
            type = 'number',
            label = 'Max Amount',
            default = zone.amount_max or 1,
            min = 1
        }
    end

    amountInputs[#amountInputs+1] = { type = 'number', label = 'Pickup Radius', default = zone.radius, min = 0.5, step = 0.1 }
    amountInputs[#amountInputs+1] = { type = 'number', label = 'Harvest Time (seconds)', default = zone.harvestTime or 3, min = 1 }
    amountInputs[#amountInputs+1] = { type = 'select', label = 'Glow Color', options = colorOptions, default = defaultColorIndex }
    amountInputs[#amountInputs+1] = { type = 'select', label = 'Pickup Animation', options = animOptions, default = defaultAnimIndex }

    for _, v in ipairs(buildRequiredItemInputs(zone.required_items)) do
        amountInputs[#amountInputs+1] = v
    end

    local step2 = lib.inputDialog('Edit Zone Settings', amountInputs)
    if not step2 then return end

    local idx = 1
    local fixedAmount, minAmount, maxAmount

    if mode == "fixed" then
        fixedAmount = step2[idx]; idx = idx + 1
    else
        minAmount = step2[idx]; idx = idx + 1
        maxAmount = step2[idx]; idx = idx + 1
    end

       local radius = step2[idx]; idx = idx + 1
    local harvestTime = step2[idx]; idx = idx + 1
    local color = ColorPresets[step2[idx]].value; idx = idx + 1

    local animIndex = step2[idx]
    local animPreset = AnimPresets[animIndex] or AnimPresets[1]
    local animDict = animPreset.dict
    local animName = animPreset.anim
    idx = idx + 1

    local required_items = {}
    for i = 1, 3 do
        local itemName = step2[idx]
        local itemCount = tonumber(step2[idx + 1])
        idx = idx + 2

        if itemName ~= "" and itemCount and itemCount > 0 then
            required_items[#required_items+1] = { name = itemName, count = itemCount }
        end
    end

    TriggerServerEvent('drugcreator:server:editZone', id, {
        label = label,
        item = item,
        amount_mode = mode,
        amount = fixedAmount,
        amount_min = minAmount,
        amount_max = maxAmount,
        radius = radius,
        harvestTime = harvestTime,
        required_items = required_items,
        color = color,
        animDict = animDict,
        animName = animName
    })
end

---------------------------------------------------------
-- DEBUG COMMAND
---------------------------------------------------------

RegisterCommand('dzdebug', function()
    print('----- DRUG ZONE DEBUG -----')
    if not zones or next(zones) == nil then
        print('No zones in client memory.')
        return
    end

    for id, zone in pairs(zones) do
        print(('[ID %s] %s | radius=%.2f | time=%s | coords=%.2f %.2f %.2f'):format(
            id,
            zone.label or 'nil',
            zone.radius or 0.0,
            tostring(zone.harvestTime or 3),
            zone.coords and zone.coords.x or 0.0,
            zone.coords and zone.coords.y or 0.0,
            zone.coords and zone.coords.z or 0.0
        ))
    end
end, false)
