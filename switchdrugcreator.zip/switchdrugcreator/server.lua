local drugZones = {}
local oxItems = exports.ox_inventory:Items()

-- ACE admin check
local function isAdmin(src)
    return IsPlayerAceAllowed(src, "drugcreator.admin")
end

---------------------------------------------------------
-- LOAD ZONES FROM DB
---------------------------------------------------------

local function loadZones()
    drugZones = {}
    local result = MySQL.query.await('SELECT * FROM drug_zones', {}) or {}

    for _, row in ipairs(result) do
        drugZones[row.id] = {
            id = row.id,
            label = row.label,
            item = row.item,
            amount = row.amount,
            amount_mode = row.amount_mode or "fixed",
            amount_min = row.amount_min or 1,
            amount_max = row.amount_max or 1,
            required_items = row.required_items and json.decode(row.required_items) or {},
            coords = vector3(row.x, row.y, row.z),
            radius = row.radius,
            harvestTime = row.harvestTime or 3,
            animDict = row.animDict or "",
            animName = row.animName or "",
            color = { r = row.color_r, g = row.color_g, b = row.color_b }
        }
    end

    print(("^2[DrugCreator]^7 Loaded %d zones."):format(#result))
end

---------------------------------------------------------
-- SYNC ZONES
---------------------------------------------------------

local function syncZones(target)
    if target then
        TriggerClientEvent('drugcreator:client:setZones', target, drugZones)
    else
        TriggerClientEvent('drugcreator:client:setZones', -1, drugZones)
    end
end

---------------------------------------------------------
-- AUTO-PATCH DATABASE (REMOVE BLIP COLUMNS)
---------------------------------------------------------

CreateThread(function()
    print("^3[DrugCreator]^7 Checking database schema...")

    -- Base table
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS drug_zones (
            id INT AUTO_INCREMENT PRIMARY KEY,
            label VARCHAR(64) NOT NULL,
            item VARCHAR(64) NOT NULL,
            amount INT NULL,
            amount_mode VARCHAR(16) NOT NULL DEFAULT 'fixed',
            amount_min INT DEFAULT 1,
            amount_max INT DEFAULT 1,
            required_items JSON NULL,
            x DOUBLE NOT NULL,
            y DOUBLE NOT NULL,
            z DOUBLE NOT NULL,
            radius DOUBLE NOT NULL DEFAULT 2.0,
            harvestTime INT NOT NULL DEFAULT 3,
            animDict VARCHAR(64) NULL,
            animName VARCHAR(64) NULL,
            color_r INT NOT NULL DEFAULT 0,
            color_g INT NOT NULL DEFAULT 255,
            color_b INT NOT NULL DEFAULT 0
        );
    ]])

    -- Remove blip columns if they exist
    local drops = {
        "ALTER TABLE drug_zones DROP COLUMN IF EXISTS blip_enabled",
        "ALTER TABLE drug_zones DROP COLUMN IF EXISTS blip_sprite",
        "ALTER TABLE drug_zones DROP COLUMN IF EXISTS blip_color"
    }

    for _, sql in ipairs(drops) do
        MySQL.query(sql)
    end

    print("^2[DrugCreator]^7 Database schema cleaned (blip fields removed).")
    loadZones()
    syncZones()
end)

---------------------------------------------------------
-- CLIENT REQUESTS ZONES
---------------------------------------------------------

RegisterNetEvent('drugcreator:server:requestZones', function()
    syncZones(source)
end)

---------------------------------------------------------
-- ADD ZONE
---------------------------------------------------------

RegisterNetEvent('drugcreator:server:addZone', function(data)
    local src = source
    if not isAdmin(src) then return end

    MySQL.insert(
        'INSERT INTO drug_zones (label, item, amount, amount_mode, amount_min, amount_max, required_items, x, y, z, radius, harvestTime, animDict, animName, color_r, color_g, color_b) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        {
            data.label,
            data.item,
            data.amount,
            data.amount_mode,
            data.amount_min,
            data.amount_max,
            json.encode(data.required_items),
            data.coords.x,
            data.coords.y,
            data.coords.z,
            data.radius,
            data.harvestTime,
            data.animDict,
            data.animName,
            data.color.r,
            data.color.g,
            data.color.b
        },
        function(insertId)
            if not insertId then return end

            drugZones[insertId] = {
                id = insertId,
                label = data.label,
                item = data.item,
                amount = data.amount,
                amount_mode = data.amount_mode,
                amount_min = data.amount_min,
                amount_max = data.amount_max,
                required_items = data.required_items,
                coords = data.coords,
                radius = data.radius,
                harvestTime = data.harvestTime,
                animDict = data.animDict,
                animName = data.animName,
                color = data.color
            }

            syncZones()
            TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'Drug zone created.' })
        end
    )
end)

---------------------------------------------------------
-- EDIT ZONE
---------------------------------------------------------

RegisterNetEvent('drugcreator:server:editZone', function(id, data)
    local src = source
    if not isAdmin(src) then return end

    id = tonumber(id)
    if not drugZones[id] then return end

    MySQL.update(
        'UPDATE drug_zones SET label=?, item=?, amount=?, amount_mode=?, amount_min=?, amount_max=?, required_items=?, radius=?, harvestTime=?, animDict=?, animName=?, color_r=?, color_g=?, color_b=? WHERE id=?',
        {
            data.label,
            data.item,
            data.amount,
            data.amount_mode,
            data.amount_min,
            data.amount_max,
            json.encode(data.required_items),
            data.radius,
            data.harvestTime,
            data.animDict,
            data.animName,
            data.color.r,
            data.color.g,
            data.color.b,
            id
        },
        function()
            local zone = drugZones[id]
            zone.label = data.label
            zone.item = data.item
            zone.amount = data.amount
            zone.amount_mode = data.amount_mode
            zone.amount_min = data.amount_min
            zone.amount_max = data.amount_max
            zone.required_items = data.required_items
            zone.radius = data.radius
            zone.harvestTime = data.harvestTime
            zone.animDict = data.animDict
            zone.animName = data.animName
            zone.color = data.color

            syncZones()
            TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'Zone updated.' })
        end
    )
end)

---------------------------------------------------------
-- DELETE ZONE
---------------------------------------------------------

RegisterNetEvent('drugcreator:server:deleteZone', function(id)
    local src = source
    if not isAdmin(src) then return end

    id = tonumber(id)
    if not drugZones[id] then return end

    MySQL.update('DELETE FROM drug_zones WHERE id = ?', { id })

    drugZones[id] = nil
    syncZones()

    TriggerClientEvent('ox_lib:notify', src, {
        type = 'success',
        description = 'Zone deleted.'
    })
end)

---------------------------------------------------------
-- PICKUP LOGIC
---------------------------------------------------------

RegisterNetEvent('drugcreator:server:pickup', function(zoneId)
    local src = source
    zoneId = tonumber(zoneId)
    local zone = drugZones[zoneId]
    if not zone then return end

    -- Required items
    if zone.required_items and #zone.required_items > 0 then
        for _, req in ipairs(zone.required_items) do
            local count = exports.ox_inventory:Search(src, 'count', req.name)
            if (count or 0) < req.count then
                TriggerClientEvent('ox_lib:notify', src, {
                    type = 'error',
                    description = ('Missing: %s x%d'):format(req.name, req.count)
                })
                return
            end
        end
        for _, req in ipairs(zone.required_items) do
            exports.ox_inventory:RemoveItem(src, req.name, req.count)
        end
    end

    -- Fixed or random amount
    local giveAmount = zone.amount
    if zone.amount_mode == "random" then
        giveAmount = math.random(zone.amount_min, zone.amount_max)
    end

    if not exports.ox_inventory:AddItem(src, zone.item, giveAmount) then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Inventory full.' })
        return
    end

    TriggerClientEvent('ox_lib:notify', src, {
        type = 'success',
        description = ('Picked up %dx %s'):format(giveAmount, zone.item)
    })
end)

---------------------------------------------------------
-- TELEPORT TO ZONE
---------------------------------------------------------

RegisterNetEvent('drugcreator:server:teleportToZone', function(id)
    local src = source
    if not isAdmin(src) then return end

    id = tonumber(id)
    local zone = drugZones[id]
    if not zone or not zone.coords then return end

    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return end

    SetEntityCoords(ped, zone.coords.x, zone.coords.y, zone.coords.z, false, false, false, true)
end)


---------------------------------------------------------
-- CALLBACKS
---------------------------------------------------------

lib.callback.register('drugcreator:server:isAdmin', function(source)
    return isAdmin(source)
end)

lib.callback.register('drugcreator:server:getZones', function(source)
    return drugZones
end)

lib.callback.register('drugcreator:server:getAllItems', function(source)
    local list = {}

    for name, data in pairs(oxItems) do
        list[#list+1] = {
            name = name,
            label = data.label or name
        }
    end

    table.sort(list, function(a, b)
        return a.label:lower() < b.label:lower()
    end)

    return list
end)

